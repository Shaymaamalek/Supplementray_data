library(tidyverse)
library(reshape2)
library(psych)
library(GGally)
library(dunn.test)
library(report)
library(car)
library(multcomp)
library(ggplot2)
library(dplyr)
library(ggpubr)
library(gridExtra)
library(patchwork)
library(MASS)

#read the csv file
data <- read.csv("C:/Users/asd/Documents/Aya/water_5plants.csv", header = TRUE, dec = ".", check.names = FALSE)

summary(water_5plants)
# Filter out control
data_no_control <- data %>% filter(Samples != "control")

# Gather readings
data_long <- data_no_control %>%
  pivot_longer(-Samples, names_to = "parameter", values_to = "value") %>%
  separate(parameter, into = c("Param", "Type"), sep = "\\(") %>%
  mutate(Type = gsub("\\)", "", Type),
         Param = trimws(Param),
         Type = case_when(Type == "diff." ~ "Diff",
                          Type == "I" ~ "Before",
                          Type == "O" ~ "After",
                          TRUE ~ Type))
#descriptive 
descriptives <- data_long %>%
  filter(Type != "Diff") %>%
  group_by(Samples, Param, Type) %>%
  summarise(mean = mean(value, na.rm = TRUE),
            sd = sd(value, na.rm = TRUE),
            min = min(value, na.rm = TRUE),
            max = max(value, na.rm = TRUE),
            .groups = "drop")
print(descriptives)

#5. Normality Test
#Use Shapiro-Wilk test on the differences:
# Get differences manually
data_wide <- data_no_control

# Get list of parameters
params <- unique(gsub("\\(.*\\)", "", names(data_wide)))
# Normality check on differences
normality_results <- data.frame()

for (param in params) {
  diff_col <- paste0(param, "(diff.)")
  if (diff_col %in% names(data_wide)) {
    shapiro <- shapiro.test(data_wide[[diff_col]])
    normality_results <- rbind(normality_results,
                               data.frame(Parameter = param,
                                          W = shapiro$statistic,
                                          p_value = shapiro$p.value))
  }
}

print(normality_results)
write.csv(normality_results, file = "normality_results.csv", row.names = FALSE)




# Normality check on differences with parametric/non-parametric classification
normality_results <- data.frame()


normality_results <- data.frame(
  Parameter = character(),
  W = numeric(),
  p_value = numeric(),
  Distribution = character(),
  Test_Type = character(),
  stringsAsFactors = FALSE
)


for (param in params) {
  diff_col <- paste0(param, "(diff.)")
  if (diff_col %in% names(data_wide)) {
    shapiro <- shapiro.test(data_wide[[diff_col]])
    dist_label <- ifelse(shapiro$p.value > 0.05, "Normal", "Not Normal")
    test_type <- ifelse(shapiro$p.value > 0.05, "Parametric", "Non-Parametric")
    
    normality_results <- rbind(normality_results,
                               data.frame(Parameter = param,
                                          W = shapiro$statistic,
                                          p_value = shapiro$p.value,
                                          Distribution = dist_label,
                                          Test_Type = test_type))
  }
}


write.csv(normality_results, file = "normality_results.csv", row.names = FALSE)


#6. Paired Tests (Parametric or Non-Parametric)
#Decide test type based on normality:

test_results <- data.frame()

for (param in params) {
  before <- paste0(param, "(I)")
  after <- paste0(param, "(O)")
  
  if (all(c(before, after) %in% names(data_wide))) {
    x <- data_wide[[before]]
    y <- data_wide[[after]]
    diff <- x - y
    
    if (shapiro.test(diff)$p.value > 0.05) {
      test <- t.test(x, y, paired = TRUE)
      method <- "paired t-test"
    } else {
      test <- wilcox.test(x, y, paired = TRUE)
      method <- "Wilcoxon signed-rank"
    }
    
    test_results <- rbind(test_results,
                          data.frame(Parameter = param,
                                     Method = method,
                                     p_value = test$p.value))
  }
}

print(test_results %>% arrange(p_value))
write.csv(test_results, file = "test_results.csv", row.names = FALSE)

#7. Visualization
#Boxplots (Before vs After for all parameters)

ggplot(data_long %>% filter(Type != "Diff"),
       aes(x = Type, y = value, fill = Type)) +
  geom_boxplot(outlier.shape = NA) +
  facet_wrap(~Param, scales = "free") +
  labs(
    title = "Before vs After Treatment - Boxplots",
    x = "Sampling Type",
    y = "Measured Value"
  ) +
  theme_minimal(base_size = 14) +
  theme(
    panel.background = element_rect(fill = "white", color = NA),
    plot.background = element_rect(fill = "white", color = NA),
    axis.text.x = element_text(angle = 45, hjust = 1, size = 14),
    axis.text.y = element_text(size = 13),
    axis.title.x = element_text(size = 15, face = "bold"),
    axis.title.y = element_text(size = 15, face = "bold"),
    strip.text = element_text(size = 16, face = "bold"),
    plot.title = element_text(size = 18, face = "bold", hjust = 0.5),
    legend.text = element_text(size = 13),
    legend.title = element_text(size = 14),
    plot.margin = margin(20, 24, 100, 24)
  )


ggsave("boxplot_before_after.png", width = 18, height = 10, dpi = 400, bg = "white")







#Distribution Shapes (Histograms for Differences)
data_diff <- data_long %>% filter(Type == "Diff")

ggplot(data_diff, aes(x = value)) +
  geom_histogram(bins = 20, fill = "skyblue", color = "black", alpha = 0.9) +
  facet_wrap(~Param, scales = "free", ncol = 4) + # Adjust ncol for best fit
  labs(
    title = "Distribution of Differences (Before - After)",
    x = "Difference (Inflow - Outflow)",
    y = "Frequency"
  ) +
  theme_minimal(base_size = 16) +
  theme(
    panel.background = element_rect(fill = "white", color = NA),
    plot.background  = element_rect(fill = "white", color = NA),
    axis.text.x      = element_text(angle = 45, hjust = 1, vjust = 1, size = 15),
    axis.text.y      = element_text(size = 14),
    axis.title.x     = element_text(size = 17, face = "bold"),
    axis.title.y     = element_text(size = 17, face = "bold"),
    strip.text       = element_text(size = 18, face = "bold"),
    plot.title       = element_text(size = 20, face = "bold", hjust = 0.5),
    plot.margin      = margin(24, 24, 32, 24)
  )

ggsave("histogram_diff.png", width = 18, height = 10, dpi = 400, bg = "white")



#✅ 8. Heatmap of Improvements
data_diff_wide <- data_diff %>%
  pivot_wider(names_from = Samples, values_from = value)

data_melt <- melt(as.matrix(data_diff_wide[,-1]))
colnames(data_melt) <- c("Parameter", "Plant", "DiffValue")

ggplot(data_long, aes(x = Type, y = value, fill = Type)) +
  geom_boxplot(outlier.shape = NA, width = 0.6) +
  facet_wrap(~Param, scales = "free", ncol = 4) +   # Adjust ncol for best layout
  scale_fill_manual(values = c("Before" = "skyblue", "After" = "orange", "Diff" = "gray")) +
  labs(
    title = "Parameter Readings: Before vs After",
    x = "Reading Type",
    y = "Measured Value",
    fill = "Reading Type"
  ) +
  theme_minimal(base_size = 16) +
  theme(
    panel.background = element_rect(fill = "white", color = NA),
    plot.background  = element_rect(fill = "white", color = NA),
    axis.text.x      = element_text(angle = 45, hjust = 1, vjust = 1, size = 15),
    axis.text.y      = element_text(size = 14),
    axis.title.x     = element_text(size = 17, face = "bold"),
    axis.title.y     = element_text(size = 17, face = "bold"),
    strip.text       = element_text(size = 18, face = "bold"),
    plot.title       = element_text(size = 20, face = "bold", hjust = 0.5),
    legend.text      = element_text(size = 14),
    legend.title     = element_text(size = 15),
    plot.margin      = margin(24, 24, 32, 24)
  )

ggsave("boxplot_parameter_readings.png", width = 18, height = 10, dpi = 400, bg = "white")


#############################################################################
# Correlations:
library(corrplot)
library(ggcorrplot)
library(readr)

# Exclude the 'control' row
data_plants <- data %>% filter(Samples != "control")

# Select only the columns containing parameter differences
diff_cols <- grep("\\(diff\\.\\)", names(data_plants), value = TRUE)

data_diff <- data_no_control %>% dplyr::select(all_of(diff_cols))

# Optionally, clean column names for better readability
colnames(data_diff) <- gsub("\\(diff\\.\\)", "", diff_cols)

#Compute Correlation Matrix

# Calculate the correlation matrix (Pearson by default)
cor_matrix <- cor(data_diff, use = "pairwise.complete.obs", method = "pearson")

# Display the rounded correlation matrix
print(round(cor_matrix, 2))

#For non-parametric (Spearman) correlation, change method = "pearson" to method = "spearman".
cor_matrix <- cor(data_diff, use = "pairwise.complete.obs", method = "spearman")

##Visualize Correlations

corrplot(cor_matrix,
         method = "color",
         type = "upper",
         tl.col = "black",
         tl.srt = 45,
         addCoef.col = "black",   # Shows numbers
         number.cex = 0.8,        # Reduce from default 1 to 0.8 (or less)
         tl.cex = 1.3,            # Axis label size
         cl.cex = 1.2,            # Color legend size
         mar = c(2,2,4,2),        # Expand plot margins
         bg = "white"
)

png("correlation_matrix.png", width = 2000, height = 1800, res = 200, bg = "white")
corrplot(
  cor_matrix,
  method = "color",
  type = "upper",
  tl.col = "black",
  addCoef.col = "black",
  number.cex = 0.8,
  tl.cex = 1.3,
  cl.cex = 1.2,
  mar = c(2,2,4,2),
  bg = "white"
)
dev.off()



#Publication-Style Plot (ggcorrplot)

corr_plot <- ggcorrplot(
  cor_matrix,
  method      = "circle",    # Circles sized/shaded by correlation
  type        = "lower",     # Show only the lower triangle
  lab         = TRUE,        # Show correlation coefficients
  lab_size    = 8,           # Large, clear numbers on circles
  colors      = c("red", "white", "blue"), # Divergent palette
  outline.col = "gray40",    # Fine outline for circles
  ggtheme     = theme_minimal(base_size = 20)
) +
  labs(title = "Correlation Matrix (Before - After Adjustment)") +
  theme(
    plot.background  = element_rect(fill = "white", color = NA),
    panel.background = element_rect(fill = "white", color = NA),
    axis.text.x      = element_text(size = 18, angle = 45, hjust = 1, face = "bold"),
    axis.text.y      = element_text(size = 18, face = "bold"),
    plot.title       = element_text(size = 24, face = "bold", hjust = 0.5, margin = margin(b = 18)),
    plot.margin      = margin(30, 30, 36, 30)
  )

# Print to check in your plotting window (optional)
print(corr_plot)

ggsave("large_corrplot.png", plot = corr_plot, width = 18, height = 11, dpi = 450, bg = "white")
############4. Notes and Interpretation
#Each cell in the matrix or plot shows the correlation between two parameter differences (e.g., between ΔBOD5 and ΔCOD).

#High absolute values (e.g., >0.7 or <–0.7) indicate strong correlations, either positive or negative, suggesting a linked removal or change pattern between those two parameters across the observed plants.

#Cells with "NA" reflect parameters where insufficient variation or missing values prevented calculation for that pair.


#################################################################################

#Calculate Pearson Correlations for Specified Pairs

# 1. BOD & COD
cor_bod_cod <- cor(data_diff$BOD5, data_diff$COD, method = "pearson")

# 2. BOD & TOC
cor_bod_toc <- cor(data_diff$BOD5, data_diff$TOC, method = "pearson")

# 3. TOC & COD
cor_toc_cod <- cor(data_diff$TOC, data_diff$COD, method = "pearson")

# 4. COD & TN
cor_cod_tn <- cor(data_diff$COD, data_diff$TN, method = "pearson")

# 5. TP & TN
cor_tp_tn <- cor(data_diff$TP, data_diff$TN, method = "pearson")

# 6. COD, BOD, TOC with Turbidity
cor_cod_turb <- cor(data_diff$COD, data_diff$Turbidity, method = "pearson")
cor_bod_turb <- cor(data_diff$BOD5, data_diff$Turbidity, method = "pearson")
cor_toc_turb <- cor(data_diff$TOC, data_diff$Turbidity, method = "pearson")

#Correlation Summary Table

#BOD & COD
cor_bod_cod

#BOD & TOC
cor_bod_toc
#TOC & COD
cor_toc_cod

#COD & TN	
cor_cod_tn
#TP & TN	
cor_tp_tn
#COD & Turbidity	
cor_cod_turb
#BOD & Turbidity	
cor_bod_turb
#TOC & Turbidity	
cor_toc_turb

###. Publication-Quality Visualization

# Helper plotting function with Pearson r in the title
plot_correlation <- function(x, y, xlab, ylab, title) {
  r_val <- cor(x, y, method = "pearson")
  ggplot(data.frame(x, y), aes(x = x, y = y)) +
    geom_point(size = 3, color = "#005A9C") +
    geom_smooth(method = "lm", se = FALSE, color = "#E66100", linetype = "dashed") +
    ggtitle(sprintf("%s\nPearson r = %.2f", title, r_val)) +
    xlab(xlab) + ylab(ylab) +
    theme_pubr(base_size = 14)
}



# Create each plot
p1 <- plot_correlation(data_diff$BOD5, data_diff$COD, "BOD5 (Diff.)", "COD (Diff.)", "BOD5 vs COD")
print(p1)
p2 <- plot_correlation(data_diff$BOD5, data_diff$TOC, "BOD5 (Diff.)", "TOC (Diff.)", "BOD5 vs TOC")
print(p2)
p3 <- plot_correlation(data_diff$TOC, data_diff$COD, "TOC (Diff.)", "COD (Diff.)", "TOC vs COD")
print(p3)
p4 <- plot_correlation(data_diff$COD, data_diff$TN, "COD (Diff.)", "TN (Diff.)", "COD vs TN")
print(p4)
p5 <- plot_correlation(data_diff$TP, data_diff$TN, "TP (Diff.)", "TN (Diff.)", "TP vs TN")
print(p5)
p6 <- plot_correlation(data_diff$COD, data_diff$Turbidity, "COD (Diff.)", "Turbidity (Diff.)", "COD vs Turbidity")
print(p6)
p7 <- plot_correlation(data_diff$BOD5, data_diff$Turbidity, "BOD5 (Diff.)", "Turbidity (Diff.)", "BOD5 vs Turbidity")
print(p7)
p8 <- plot_correlation(data_diff$TOC, data_diff$Turbidity, "TOC (Diff.)", "Turbidity (Diff.)", "TOC vs Turbidity")
print(p8)
#####################################################################


library(gridExtra)
library(ggplot2)
library(dplyr)

#combine blot

combined_plot <- (p1 | p2 | p3) / 
  (p4 | p5 | p6) / 
  (p7 | p8 | patchwork::plot_spacer())

# Display the combined plot
print(combined_plot)

ggsave(
  filename = "combined_blots.png",
  plot = combined_plot,
  width = 18,      # Choose width to comfortably fit all columns
  height = 12,     # Height for rows
  dpi = 400,       # High resolution for publication/presentation
  bg = "white"     # Ensures a solid white background
)

###################################################################finish######






library(dplyr)
library(tidyr)
library(ggplot2)
library(readr)
library(reshape2)




# Filter out the control sample
data_plants <- data %>% filter(Samples != "control")

# Select difference columns only
diff_cols <- grep("\\(diff\\.\\)", names(data_plants), value = TRUE)
data_efficacy <- data_plants %>% select(Samples, all_of(diff_cols))

# Clean parameter names
colnames(data_efficacy) <- gsub("\\(diff\\.\\)", "", colnames(data_efficacy))

# Reshape data for easy summary and visualization
data_long <- data_efficacy %>%
  pivot_longer(-Samples, names_to = "Parameter", values_to = "Reduction")

# Calculate descriptive statistics for each parameter across plants
efficacy_summary <- data_long %>%
  group_by(Parameter) %>%
  summarise(
    mean_reduction = mean(Reduction, na.rm = TRUE),
    sd = sd(Reduction, na.rm = TRUE),
    min = min(Reduction, na.rm = TRUE),
    max = max(Reduction, na.rm = TRUE)
  )
print(efficacy_summary)
write.csv(efficacy_summary, "efficacy_summary.csv", row.names = FALSE)

report(efficacy_summary)

# Calculate mean and standard deviation for each group
summary_df <- data_long %>%
  group_by(Parameter, Samples) %>%
  summarise(
    mean_reduction = mean(Reduction, na.rm = TRUE),
    sd_reduction = sd(Reduction, na.rm = TRUE)
  )


# Plot grouped bar chart with error bars
# Filter only the relevant parameters
metals_params <- c("pH", "DO", "TP", "CN", "Pb", "Ni", "Cd", "Cu", "Fe", "Zn", "Hg", "As")
summary_metals <- summary_df %>%
  filter(Parameter %in% metals_params)

# Plot
ggplot(summary_metals, aes(x = Parameter, y = mean_reduction, fill = Samples)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.8), width = 0.7) +
  geom_errorbar(aes(ymin = mean_reduction - sd_reduction, ymax = mean_reduction + sd_reduction),
                width = 0.2, position = position_dodge(width = 0.8)) +
  labs(title = "Treatment Efficacy (Mean Reduction) – Metals & Priorities",
       y = "Mean Reduction (Inflow - Outflow)",
       x = "Parameter") +
  theme_minimal(base_size = 16) +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, size = 14),
    axis.text.y = element_text(size = 13),
    axis.title.x = element_text(size = 16, face = "bold"),
    axis.title.y = element_text(size = 16, face = "bold"),
    plot.title = element_text(size = 18, face = "bold", hjust = 0.5)
  )
ggsave("metals_efficacy_barplot.png", width = 13, height = 8, dpi = 400, bg = "white")

# Filter only the relevant parameters
org_params <- c("BOD5", "COD", "TOC", "TDS", "EC", "TN", "Turbidity")
summary_organics <- summary_df %>%
  filter(Parameter %in% org_params)

# Plot
ggplot(summary_organics, aes(x = Parameter, y = mean_reduction, fill = Samples)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.8), width = 0.7) +
  geom_errorbar(aes(ymin = mean_reduction - sd_reduction, ymax = mean_reduction + sd_reduction),
                width = 0.2, position = position_dodge(width = 0.8)) +
  labs(title = "Treatment Efficacy (Mean Reduction) – Organic & Aggregate",
       y = "Mean Reduction (Inflow - Outflow)",
       x = "Parameter") +
  theme_minimal(base_size = 16) +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, size = 14),
    axis.text.y = element_text(size = 13),
    axis.title.x = element_text(size = 16, face = "bold"),
    axis.title.y = element_text(size = 16, face = "bold"),
    plot.title = element_text(size = 18, face = "bold", hjust = 0.5)
  )

ggsave("organics_efficacy_barplot.png", width = 13, height = 8, dpi = 400, bg = "white")


# Install if needed: 
# Desired parameter order (with code-notation where needed)
ordered_params <- c(
  "Turbidity", "BOD5", "COD", "TOC",
  "TDS", "EC", "CN", "TP", "TN",  # PO4 = "TP", N = "TN"
  "Pb", "Ni", "Cd", "Cu", "Fe", "Zn", "Hg", "As"
)

# Re-label for x-axis: show "TP" instead of "PO4", "TN" for "N"
axis_labels <- c(
  "Turbidity", "BOD5", "COD", "TOC",
  "TDS", "EC", "CN", "TP", "TN",
  "Pb", "Ni", "Cd", "Cu", "Fe", "Zn", "Hg", "As"
)

# Prepare your data frame (data_long) so Parameter is a factor in this order
data_long <- data_long %>%
  filter(Parameter %in% ordered_params) %>%
  mutate(Parameter = factor(Parameter, levels = ordered_params, labels = axis_labels))

# Now your plotting code:
library(ggdist) # For stat_halfeye

p <- ggplot(data_long, aes(x = Parameter, y = Reduction, fill = Samples, color = Samples)) +
  stat_halfeye(
    adjust = 0.5, justification = -0.2, .width = 0,
    point_colour = NA, position = position_dodge(width = 0.8)
  ) +
  geom_boxplot(width = 0.12, outlier.color = NA, alpha = 0.5, position = position_dodge(width = 0.8)) +
  geom_jitter(position = position_jitterdodge(jitter.width = 0.15, dodge.width = 0.8),
              size = 1.5, alpha = 0.7, show.legend = FALSE) +
  labs(title = "Raincloud Plot: Efficacy Reduction by Parameter and Plant",
       y = "Reduction (Inflow - Outflow)",
       x = "Parameter") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

# Print the plot
print(p)

# Optional: Save the figure
ggsave("raincloud_plot_all_parameters.png", plot = p, width = 18, height = 7, dpi = 400, bg = "white")




##################################################################
#effeciency table
library(dplyr)
library(readr)
library(tidyr)


# Remove the control sample
data_plants <- data %>% filter(Samples != "control")

# Identify all parameters (those with '(I)' and '(O)')
params_in <- grep("\\(I\\)", names(data_plants), value = TRUE)
params_out <- grep("\\(O\\)", names(data_plants), value = TRUE)

# Standardize parameter names
param_names <- gsub("\\(I\\)", "", params_in)

# Prepare empty data frame for results
removal_results <- data.frame(Samples = data_plants$Samples)

# Calculate removal efficiency for each parameter
for (i in seq_along(param_names)) {
  p_in <- params_in[i]
  p_out <- params_out[i]
  p_eff <- paste0(trimws(param_names[i]), "_eff")
  removal <- 100 * (data_plants[[p_in]] - data_plants[[p_out]]) / data_plants[[p_in]]
  removal_results[[gsub("^\\.| ", "", p_eff)]] <- round(removal, 2)
}

# Combine with plant names
removal_table <- cbind(Sample = data_plants$Samples, removal_results[-1])

# Print the final removal efficiency table
print(removal_table)

# Optional: Save to CSV for reporting
write.csv(removal_table, "removal_efficiency_by_plant.csv", row.names = FALSE)
##################################################################
#whole efficacy: organic compounds and aggregates

library(tidyverse)

# Define your organic and aggregate parameters in your dataset
organic_params <- c("BOD5", "COD", "TOC")          # Adjust as needed
aggregate_params <- c("TDS", "EC")                 # Add other aggregate params as needed

# Combine parameters
all_params <- c(organic_params, aggregate_params)

# Keep Samples and relevant columns
selected_cols <- c("Samples", unlist(lapply(all_params, function(p) c(paste0(p, "(I)"), paste0(p, "(O)")))))

data_sel <- data %>%
  select(all_of(selected_cols)) %>%
  mutate(across(-Samples, as.numeric))   # ensure numeric columns
# Calculate removal efficacy for each parameter and plant
calc_removal <- function(i, o) {
  ifelse(i == 0, NA, (i - o) / i * 100)
}

# Calculate removal efficacy columns
for (p in all_params) {
  i_col <- paste0(p, "(I)")
  o_col <- paste0(p, "(O)")
  removal_col <- paste0(p, "_Removal")
  data_sel[[removal_col]] <- calc_removal(data_sel[[i_col]], data_sel[[o_col]])
}

# Compute the average removal efficacy across all parameters for each plant
data_sel %>%
  mutate(
    Overall_Removal = rowMeans(select(., ends_with("_Removal")), na.rm = TRUE)
  ) %>%
  select(Samples, Overall_Removal) %>%
  arrange(desc(Overall_Removal)) %>%
  print()
########################################
#Overall miniral


library(tidyverse)
library(readr)

# List of all parameters to include
target_params <- c("Pb", "Ni", "Cd", "Cu", "Fe", "Zn", "Hg", "As", "TP", "TN")

# Gather (I) and (O) columns for each target parameter
required_cols <- c("Samples", unlist(lapply(target_params, function(p) c(paste0(p, "(I)"), paste0(p, "(O)")))))

data_targets <- data %>%
  select(all_of(required_cols)) %>%
  mutate(across(-Samples, as.numeric))

# Removal efficacy formula
calc_removal <- function(i, o) ifelse(is.na(i) | i == 0, NA, (i - o) / i * 100)

# Calculate removal for each parameter
for (p in target_params) {
  i_col <- paste0(p, "(I)")
  o_col <- paste0(p, "(O)")
  data_targets[[paste0(p, "_Removal")]] <- calc_removal(data_targets[[i_col]], data_targets[[o_col]])
}

# Average across all target parameters per plant
data_targets %>%
  mutate(
    Overall_Heavy_TP_TN_Removal = rowMeans(select(., ends_with("_Removal")), na.rm = TRUE)
  ) %>%
  select(Samples, Overall_Heavy_TP_TN_Removal) %>%
  print()

######################################################
library(tidyverse)

# Select only the parameters of interest
selected_params <- c("TP", "Ni", "Cu", "Fe") # PO4 = TP
summary_subset <- summary_df %>%
  filter(Parameter %in% selected_params)
ordered_params <- c("TP", "Ni", "Cu", "Fe")


summary_subset <- summary_subset %>%
  mutate(Parameter = factor(Parameter, levels = ordered_params, labels = c("TP", "Ni", "Cu", "Fe")))


# Plot grouped bar chart with error bars
p <- ggplot(summary_subset,
            aes(x = Parameter, y = mean_reduction, fill = Samples)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.8), width = 0.7) +
  geom_errorbar(aes(ymin = mean_reduction - sd_reduction,
                    ymax = mean_reduction + sd_reduction),
                width = 0.2, position = position_dodge(width = 0.8)) +
  labs(
    y = "Mean Reduction (Inflow - Outflow)",
    x = "Parameter"
  ) +
  theme_minimal(base_size = 16) +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, size = 14),
    axis.text.y = element_text(size = 13),
    axis.title.x = element_text(size = 13, face = "bold"),
    axis.title.y = element_text(size = 13, face = "bold"),
    plot.title = element_text(size = 10, face = "bold", hjust = 0.5)
  )

# Display plot in RStudio
print(p)
# Save as PNG
ggsave("ordered_params_efficacy_barplot.png", plot = p, width = 10, height = 7, dpi = 400, bg = "white")


# 1. Select only the parameters of interest, in the desired order
selected_params <- c("CN", "Pb", "Cd", "Zn", "Hg", "As")
ordered_params <- selected_params  # To match the visual and factor order

# 2. Filter and set the factor with the required ordering
summary_subset <- summary_df %>%
  filter(Parameter %in% selected_params) %>%
  mutate(Parameter = factor(Parameter, levels = ordered_params, labels = ordered_params))

# 3. Plot grouped bar chart with error bars
p <- ggplot(summary_subset,
            aes(x = Parameter, y = mean_reduction, fill = Samples)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.8), width = 0.7) +
  geom_errorbar(aes(ymin = mean_reduction - sd_reduction,
                    ymax = mean_reduction + sd_reduction),
                width = 0.2, position = position_dodge(width = 0.8)) +
  labs(
    y = "Mean Reduction (Inflow - Outflow)",
    x = "Parameter"
  ) +
  theme_minimal(base_size = 16) +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, size = 14),
    axis.text.y = element_text(size = 13),
    axis.title.x = element_text(size = 13, face = "bold"),
    axis.title.y = element_text(size = 13, face = "bold"),
    plot.title = element_text(size = 13, face = "bold", hjust = 0.5)
  )

print(p)
ggsave("treatment_efficacy_CN_Pb_Cd_Zn_Hg_As.png", plot = p, width = 10, height = 7, dpi = 400, bg = "white")

# 1. Specify parameters and their order
selected_params <- c("Turbidity", "BOD5", "COD", "TOC", "TDS", "EC", "TN")  # N = TN
ordered_params <- selected_params
# 2. Prepare data: filter and set the factor
summary_subset <- summary_df %>%
  filter(Parameter %in% selected_params) %>%
  mutate(
    Parameter = factor(Parameter, levels = ordered_params,
                       labels = c("Turbidity", "BOD5", "COD", "TOC", "TDS", "EC", "TN"))
  )

# 3. Plot grouped bar chart with error bars
p <- ggplot(summary_subset,
            aes(x = Parameter, y = mean_reduction, fill = Samples)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.8), width = 0.7) +
  geom_errorbar(aes(ymin = mean_reduction - sd_reduction,
                    ymax = mean_reduction + sd_reduction),
                width = 0.2, position = position_dodge(width = 0.8)) +
  labs(
    title = "Treatment Efficacy (Mean Reduction) – Turbidity, BOD5, COD, TOC, TDS, EC, TN",
    y = "Mean Reduction (Inflow - Outflow)",
    x = "Parameter"
  ) +
  theme_minimal(base_size = 16) +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, size = 14),
    axis.text.y = element_text(size = 13),
    axis.title.x = element_text(size = 16, face = "bold"),
    axis.title.y = element_text(size = 16, face = "bold"),
    plot.title = element_text(size = 18, face = "bold", hjust = 0.5)
  )

# 4. Display and save the plot
print(p)
ggsave("treatment_efficacy_Turbidity_BOD5_COD_TOC_TDS_EC_TN.png", plot = p, width = 10, height = 7, dpi = 400, bg = "white")

#####################
# --- First chart: DO, TP, Ni, Cu, Fe ---
params1 <- c("TP", "Ni", "Cu", "Fe")
plot1 <- summary_df %>%
  filter(Parameter %in% params1) %>%
  mutate(Parameter = factor(Parameter, levels = params1)) %>%
  ggplot(aes(x = Parameter, y = mean_reduction, fill = Samples)) +
  geom_bar(stat = "identity", position = position_dodge(0.8), width = 0.7) +
  geom_errorbar(aes(ymin = mean_reduction - sd_reduction, ymax = mean_reduction + sd_reduction),
                width = 0.2, position = position_dodge(0.8)) +
  labs(y = "Mean Reduction", x = "Parameter") +
  theme_minimal(base_size = 14) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

# --- Second chart: pH, CN, Pb, Cd, Zn, Hg, As ---
params2 <- c("CN", "Pb", "Cd", "Zn", "Hg", "As")
plot2 <- summary_df %>%
  filter(Parameter %in% params2) %>%
  mutate(Parameter = factor(Parameter, levels = params2)) %>%
  ggplot(aes(x = Parameter, y = mean_reduction, fill = Samples)) +
  geom_bar(stat = "identity", position = position_dodge(0.8), width = 0.7) +
  geom_errorbar(aes(ymin = mean_reduction - sd_reduction, ymax = mean_reduction + sd_reduction),
                width = 0.2, position = position_dodge(0.8)) +
  labs(y = "Mean Reduction", x = "Parameter") +
  theme_minimal(base_size = 14) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

# --- Combine plots side-by-side ---
combined_plot <- plot1 | plot2

# Display combined plot
print(combined_plot)

# Save the combined plot as a PNG
ggsave("combined_DO_TP_Ni_Cu_Fe_pH_CN_Pb_Cd_Zn_Hg_As.png", 
       plot = combined_plot, width = 18, height = 7, dpi = 400, bg = "white")









